"""
两层特征融合；交叉注意力机制;1x1卷积降维
backbone: infrared-vgg16; visible-vgg16; decomp_base-vit; decomp_detail-交叉注意力模块
"""
import tensorflow as tf
from tensorflow import keras
import ds_layers
import decision_layer
from keras import layers, models
import os
import pandas as pd
from keras.callbacks import ModelCheckpoint
import numpy as np
from keras.layers import Dense, LayerNormalization, Dropout


class reliability(tf.keras.layers.Layer):
    def __init__(self):
        super(reliability, self).__init__()

    def call(self, inputs):
        u1, u2, u3, u4 = inputs
        u = tf.concat([u1, u2, u3, u4], axis=-1)
        u_sum = tf.reduce_sum(u, axis=-1, keepdims=True)
        rel = tf.subtract(1., tf.divide(u, u_sum))  # (None, 4)
        return rel


class mass_fusion(tf.keras.layers.Layer):
    def __init__(self):
        super(mass_fusion, self).__init__()

    def call(self, input):
        inputs1, inputs2, inputs3, inputs4, input_rel = input  # input_rel:reliability
        inputs1 = tf.expand_dims(inputs1, axis=1)
        inputs2 = tf.expand_dims(inputs2, axis=1)
        inputs3 = tf.expand_dims(inputs3, axis=1)
        inputs4 = tf.expand_dims(inputs4, axis=1)
        inputs = tf.concat([inputs1, inputs2, inputs3, inputs4], axis=1)
        input_rel = tf.expand_dims(input_rel, axis=-1)

        mass_class = inputs[:, :, 0:-1]
        re_mass_class = tf.multiply(input_rel, mass_class, name=None)
        re_mass_u = tf.subtract(1., tf.reduce_sum(re_mass_class, axis=-1, keepdims=True))
        re_inputs = tf.concat([re_mass_class, re_mass_u], axis=-1)

        m1 = re_inputs[:, 0, :]
        omega1 = tf.expand_dims(re_inputs[:, 0, -1], -1)
        for i in range(3):
            m2 = re_inputs[:, (i + 1), :]
            omega2 = tf.expand_dims(re_inputs[:, (i + 1), -1], -1)
            combine1 = tf.multiply(m1, m2, name=None)
            combine2 = tf.multiply(m1, omega2, name=None)
            combine3 = tf.multiply(omega1, m2, name=None)
            combine1_2 = tf.add(combine1, combine2, name=None)
            combine2_3 = tf.add(combine1_2, combine3, name=None)
            combine2_3 = combine2_3 / tf.reduce_sum(combine2_3, axis=-1, keepdims=True)
            m1 = combine2_3
            omega1 = tf.expand_dims(combine2_3[:, -1], -1)
        return m1


# 交叉注意力机制
class CrossAttention(layers.Layer):
    def __init__(self, num_heads, key_dim):
        super(CrossAttention, self).__init__()
        self.attention = layers.MultiHeadAttention(num_heads=num_heads, key_dim=key_dim)
        self.layer_norm = LayerNormalization(epsilon=1e-6)

    def call(self, query, value):
        attention_output = self.attention(query, value)
        return self.layer_norm(attention_output + query)


class ViTBlock(layers.Layer):
    def __init__(self, num_heads, key_dim, ff_dim, rate=0.1):
        super(ViTBlock, self).__init__()
        self.attention = layers.MultiHeadAttention(num_heads=num_heads, key_dim=key_dim)

        self.ffn = models.Sequential([
            layers.Dense(ff_dim, activation='relu'),
            layers.Dense(key_dim * num_heads)
        ])

        self.projection = layers.Dense(key_dim * num_heads)
        self.layernorm1 = layers.LayerNormalization(epsilon=1e-6)
        self.layernorm2 = layers.LayerNormalization(epsilon=1e-6)
        self.dropout1 = layers.Dropout(rate)
        self.dropout2 = layers.Dropout(rate)

    def call(self, inputs):
        attn_output = self.attention(inputs, inputs)
        attn_output = self.dropout1(attn_output)
        out1 = self.layernorm1(inputs + attn_output)
        ffn_output = self.ffn(out1)
        ffn_output = self.dropout2(ffn_output)

        return self.layernorm2(self.projection(out1) + ffn_output)


# Re-Softmax交叉注意力机制
class ReSoftmaxCrossAttention(layers.Layer):
    def __init__(self, num_heads, key_dim, **kwargs):
        super(ReSoftmaxCrossAttention, self).__init__(**kwargs)
        self.num_heads = num_heads
        self.key_dim = key_dim
        self.query_dense = Dense(key_dim)
        self.key_dense = Dense(key_dim)
        self.value_dense = Dense(key_dim)
        self.output_dense = Dense(key_dim)
        self.layer_norm = LayerNormalization(epsilon=1e-6)

    def call(self, query, value):
        Q = self.query_dense(query)
        K = self.key_dense(value)
        V = self.value_dense(value)

        scores = tf.matmul(Q, K, transpose_b=True)
        weights = tf.nn.softmax(-scores, axis=-1)

        attention_output = tf.matmul(weights, V)
        attention_output = self.output_dense(attention_output)
        return self.layer_norm(attention_output + query)


# Transformer Encoder层
class ReTransformerEncoderLayer(layers.Layer):
    def __init__(self, num_heads, key_dim, ff_dim, **kwargs):
        super(ReTransformerEncoderLayer, self).__init__(**kwargs)
        self.attention = ReSoftmaxCrossAttention(num_heads=num_heads, key_dim=key_dim)
        self.ffn = tf.keras.Sequential([
            Dense(ff_dim, activation='relu'),
            Dense(key_dim)
        ])
        self.layer_norm1 = LayerNormalization(epsilon=1e-6)
        self.layer_norm2 = LayerNormalization(epsilon=1e-6)
        self.dropout = Dropout(0.1)

    def call(self, query, value):
        attention_output = self.attention(query, value)
        attention_output = self.layer_norm1(attention_output + query)

        ffn_output = self.ffn(attention_output)
        ffn_output = self.layer_norm2(ffn_output + attention_output)

        return self.dropout(ffn_output)


def build_vgg_branch(input_shape):
    base_model = tf.keras.applications.VGG16(include_top=False, weights='imagenet', input_shape=input_shape)
    for layer in base_model.layers:
        if any(block_name in layer.name for block_name in ["block1", "block2", "block3", "block4"]):
            layer.trainable = False
        else:
            layer.trainable = True

    intermediate_layer1 = base_model.get_layer('block2_pool').output
    intermediate_layer3 = base_model.get_layer('block4_pool').output
    final_layer = base_model.output

    model = models.Model(inputs=base_model.input,
                         outputs=[intermediate_layer1, intermediate_layer3, final_layer])
    return model


def correlation(ir, rgb):
    eps = tf.keras.backend.epsilon()
    ir = tf.transpose(ir, perm=[0, 3, 1, 2])
    rgb = tf.transpose(rgb, perm=[0, 3, 1, 2])
    n, c, h, w = ir.shape
    ir = tf.reshape(ir, [-1, c, h * w])
    rgb = tf.reshape(rgb, [-1, c, h * w])
    ir = ir - tf.reduce_mean(ir, axis=-1, keepdims=True)
    rgb = rgb - tf.reduce_mean(rgb, axis=-1, keepdims=True)
    cc = tf.reduce_sum(ir * rgb, axis=-1) / (
            eps + tf.sqrt(tf.reduce_sum(ir ** 2, axis=-1)) * tf.sqrt(tf.reduce_sum(rgb ** 2, axis=-1)))
    cc = tf.clip_by_value(cc, -1., 1.)
    cc = tf.reduce_mean(cc)
    return cc


def loss_decom(ir_b, rgb_b, ir_d, rgb_d):
    cc_b1 = correlation(ir_b, rgb_b)
    cc_d1 = correlation(ir_d, rgb_d)
    loss_decomposition = cc_d1 ** 2 / (cc_b1 + 0.01)
    return loss_decomposition


class pl_loss(tf.keras.layers.Layer):
    def __init__(self, lam1, lam2):
        super(pl_loss, self).__init__()
        self.lam1 = lam1
        self.lam2 = lam2

    def call(self, inputs):
        y_true, y_weight1, y_weight2, y_weight3, y_weight4, y_pred, \
         ir_b1, rgb_b1, ir_d1, rgb_d1, ir_b2, rgb_b2, ir_d2, rgb_d2 = inputs

        loss_single = tf.multiply(y_true, tf.math.log(tf.clip_by_value(y_pred, 1e-10, 1.0)), name=None)
        loss_single = -tf.reduce_sum(loss_single, axis=-1)
        ce_loss = tf.reduce_mean(loss_single)

        pl_loss1 = tf.reduce_sum(y_true * y_weight1, -1)
        pl_loss1 = tf.reduce_mean(pl_loss1)

        pl_loss2 = tf.reduce_sum(y_true * y_weight2, -1)
        pl_loss2 = tf.reduce_mean(pl_loss2)

        pl_loss3 = tf.reduce_sum(y_true * y_weight3, -1)
        pl_loss3 = tf.reduce_mean(pl_loss3)

        pl_loss4 = tf.reduce_sum(y_true * y_weight4, -1)
        pl_loss4 = tf.reduce_mean(pl_loss4)

        loss_decomposition1 = loss_decom(ir_b1, rgb_b1, ir_d1, rgb_d1)
        loss_decomposition2 = loss_decom(ir_b2, rgb_b2, ir_d2, rgb_d2)

        total_loss = ce_loss + self.lam1 * pl_loss1 + self.lam1 * pl_loss2 + self.lam1 * pl_loss3 + \
            self.lam1 * pl_loss4 + self.lam2 * loss_decomposition1 + self.lam2 * loss_decomposition2

        # metric
        acc = keras.metrics.categorical_accuracy(y_true, y_pred)
        self.add_loss(total_loss, inputs=True)
        self.add_metric(acc, name="accuracy")
        return total_loss


def my_model():
    input_shape = (224, 224, 3)
    prototypes = 6
    num_class = 6
    lam1 = 0.1
    lam2 = 0.1
    num_heads = 2
    key_dim = 64
    ff_dim = 128
    num_heads_cm = 1
    key_dim_cm = 128
    ff_dim_cm = 128

    infrared_model = build_vgg_branch(input_shape)
    visible_model = build_vgg_branch(input_shape)

    infrared_input = infrared_model.input
    visible_input = visible_model.input
    label_input = layers.Input(shape=(num_class,), name='label_input')

    p1_ir, p3_ir, p4_ir = infrared_model(infrared_input)
    p1_rgb, p3_rgb, p4_rgb = visible_model(visible_input)

    feature_ir = tf.keras.layers.Conv2D(128, (1, 1), activation='relu', kernel_initializer='he_normal', padding='same')(p4_ir)
    feature_ir = layers.BatchNormalization()(feature_ir)
    feature_ir = layers.GlobalAveragePooling2D()(feature_ir)
    feature_rgb = tf.keras.layers.Conv2D(128, (1, 1), activation='relu', kernel_initializer='he_normal', padding='same')(p4_rgb)
    feature_rgb = layers.BatchNormalization()(feature_rgb)
    feature_rgb = layers.GlobalAveragePooling2D()(feature_rgb)

    # feature fusion-1
    feature_ir_1 = layers.Conv2D(128, (1, 1), activation='relu', kernel_initializer='he_normal', padding='same')(p1_ir)
    feature_ir_1 = layers.BatchNormalization()(feature_ir_1)
    feature_ir_1 = layers.GlobalAveragePooling2D()(feature_ir_1)
    feature_ir_1 = layers.Reshape((1, 1, -1))(feature_ir_1)

    feature_rgb_1 = layers.Conv2D(128, (1, 1), activation='relu', kernel_initializer='he_normal', padding='same')(p1_rgb)
    feature_rgb_1 = layers.BatchNormalization()(feature_rgb_1)
    feature_rgb_1 = layers.GlobalAveragePooling2D()(feature_rgb_1)
    feature_rgb_1 = layers.Reshape((1, 1, -1))(feature_rgb_1)

    feature_ir_1 = CrossAttention(num_heads=4, key_dim=64)(feature_ir_1, feature_rgb_1)
    feature_rgb_1 = CrossAttention(num_heads=4, key_dim=64)(feature_rgb_1, feature_ir_1)

    vit_base_ir_1 = ViTBlock(num_heads, key_dim, ff_dim)(feature_ir_1)
    final_base_ir_1 = layers.GlobalAveragePooling2D()(vit_base_ir_1)
    vit_base_rgb_1 = ViTBlock(num_heads, key_dim, ff_dim)(feature_rgb_1)
    final_base_rgb_1 = layers.GlobalAveragePooling2D()(vit_base_rgb_1)

    detail_ir_1_feature = ReTransformerEncoderLayer(num_heads_cm, key_dim_cm, ff_dim_cm)(feature_ir_1, feature_rgb_1)
    final_detail_ir_1 = layers.GlobalAveragePooling2D()(detail_ir_1_feature)
    detail_rgb_1_feature = ReTransformerEncoderLayer(num_heads_cm, key_dim_cm, ff_dim_cm)(feature_rgb_1, feature_ir_1)
    final_detail_rgb_1 = layers.GlobalAveragePooling2D()(detail_rgb_1_feature)

    base_1 = layers.add([final_base_ir_1, final_base_rgb_1])
    detail_1 = layers.add([final_detail_ir_1, final_detail_rgb_1])

    fusion_1 = layers.concatenate([base_1, detail_1], axis=-1)
    dense_fusion_1 = layers.Dense(128, activation='relu')(fusion_1)

    # feature fusion-3
    feature_ir_3 = layers.Conv2D(128, (1, 1), activation='relu', kernel_initializer='he_normal', padding='same')(p3_ir)
    feature_ir_3 = layers.BatchNormalization()(feature_ir_3)
    feature_ir_3 = layers.GlobalAveragePooling2D()(feature_ir_3)
    feature_ir_3 = layers.Reshape((1, 1, -1))(feature_ir_3)  # 将输出形状调整为适合CA输入
    # feature decomposition of visible image
    feature_rgb_3 = layers.Conv2D(128, (1, 1), activation='relu', kernel_initializer='he_normal', padding='same')(p3_rgb)
    feature_rgb_3 = layers.BatchNormalization()(feature_rgb_3)
    feature_rgb_3 = layers.GlobalAveragePooling2D()(feature_rgb_3)
    feature_rgb_3 = layers.Reshape((1, 1, -1))(feature_rgb_3)

    feature_ir_3 = CrossAttention(num_heads=4, key_dim=64)(feature_ir_3, feature_rgb_3)
    feature_rgb_3 = CrossAttention(num_heads=4, key_dim=64)(feature_rgb_3, feature_ir_3)

    vit_base_ir_3 = ViTBlock(num_heads, key_dim, ff_dim)(feature_ir_3)
    final_base_ir_3 = layers.GlobalAveragePooling2D()(vit_base_ir_3)
    vit_base_rgb_3 = ViTBlock(num_heads, key_dim, ff_dim)(feature_rgb_3)
    final_base_rgb_3 = layers.GlobalAveragePooling2D()(vit_base_rgb_3)

    detail_ir_3_feature = ReTransformerEncoderLayer(num_heads_cm, key_dim_cm, ff_dim_cm)(feature_ir_3, feature_rgb_3)
    final_detail_ir_3 = layers.GlobalAveragePooling2D()(detail_ir_3_feature)
    detail_rgb_3_feature = ReTransformerEncoderLayer(num_heads_cm, key_dim_cm, ff_dim_cm)(feature_rgb_3, feature_ir_3)
    final_detail_rgb_3 = layers.GlobalAveragePooling2D()(detail_rgb_3_feature)

    base_3 = layers.add([final_base_ir_3, final_base_rgb_3])
    detail_3 = layers.add([final_detail_ir_3, final_detail_rgb_3])

    fusion_3 = layers.concatenate([base_3, detail_3], axis=-1)
    dense_fusion_3 = layers.Dense(128, activation='relu')(fusion_3)

    # evidential classifier-1
    distance_1 = ds_layers.Distance(prototypes, 128)(dense_fusion_1)
    dis_activation_1 = ds_layers.DS1_activate()(distance_1)
    mass_prototypes_1 = ds_layers.DS2_mass()(dis_activation_1)
    mass_with_omega_1 = ds_layers.DS2_mass_omega()(mass_prototypes_1)
    mass_1 = ds_layers.DS3_Dempster_mass(num_class)(mass_with_omega_1)
    uncertainty_m1 = ds_layers.mass_uncertainty(num_class)(mass_1)

    # evidential classifier-3
    distance_3 = ds_layers.Distance(prototypes, 128)(dense_fusion_3)
    dis_activation_3 = ds_layers.DS1_activate()(distance_3)
    mass_prototypes_3 = ds_layers.DS2_mass()(dis_activation_3)
    mass_with_omega_3 = ds_layers.DS2_mass_omega()(mass_prototypes_3)
    mass_3 = ds_layers.DS3_Dempster_mass(num_class)(mass_with_omega_3)
    uncertainty_m3 = ds_layers.mass_uncertainty(num_class)(mass_3)

    # evidential classifier-ir
    distance_ir = ds_layers.Distance(prototypes, 128)(feature_ir)
    dis_activation_ir = ds_layers.DS1_activate()(distance_ir)
    mass_prototypes_ir = ds_layers.DS2_mass()(dis_activation_ir)
    mass_with_omega_ir = ds_layers.DS2_mass_omega()(mass_prototypes_ir)
    mass_ir = ds_layers.DS3_Dempster_mass(num_class)(mass_with_omega_ir)
    uncertainty_ir = ds_layers.mass_uncertainty(num_class)(mass_ir)

    # evidential classifier-rgb
    distance_rgb = ds_layers.Distance(prototypes, 128)(feature_rgb)
    dis_activation_rgb = ds_layers.DS1_activate()(distance_rgb)
    mass_prototypes_rgb = ds_layers.DS2_mass()(dis_activation_rgb)
    mass_with_omega_rgb = ds_layers.DS2_mass_omega()(mass_prototypes_rgb)
    mass_rgb = ds_layers.DS3_Dempster_mass(num_class)(mass_with_omega_rgb)
    uncertainty_rgb = ds_layers.mass_uncertainty(num_class)(mass_rgb)

    rel = reliability()([uncertainty_m1, uncertainty_m3, uncertainty_ir, uncertainty_rgb])

    # decision fusion
    mass = mass_fusion()([mass_1, mass_3, mass_ir, mass_rgb, rel])
    outputs = decision_layer.DM_train(0.5, num_class)(mass)

    my_loss = pl_loss(lam1, lam2)([label_input, distance_1, distance_3, distance_ir, distance_rgb,
                                  outputs, vit_base_ir_1, vit_base_rgb_1, detail_ir_1_feature, detail_rgb_1_feature,
                                  vit_base_ir_3, vit_base_rgb_3, detail_ir_3_feature, detail_rgb_3_feature])

    model = tf.keras.Model(inputs=[infrared_input, visible_input, label_input], outputs=[outputs, my_loss])
    model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.001), run_eagerly=True)
    return model


def load_image_ir(image_file):
    image = tf.io.read_file(image_file)
    image = tf.image.decode_image(image, channels=3)
    return image


def load_image(image_file):
    image = tf.io.read_file(image_file)
    image = tf.image.decode_image(image, channels=3)
    return image


def load_data(train_infrared_dir, train_visible_dir, train_labels_file,
              test_infrared_dir, test_visible_dir, test_labels_file, num_classes=6):
    # 读取训练集标签文件
    train_labels_df = pd.read_csv(train_labels_file)
    train_filenames = train_labels_df['filename'].values
    train_labels = train_labels_df['label'].values
    # 读取测试集标签文件
    test_labels_df = pd.read_csv(test_labels_file)
    test_filenames = test_labels_df['filename'].values
    test_labels = test_labels_df['label'].values

    # 生成训练集图像路径
    train_infrared_files = [os.path.join(train_infrared_dir, f) for f in train_filenames]
    train_visible_files = [os.path.join(train_visible_dir, f) for f in train_filenames]
    # 生成测试集图像路径
    test_infrared_files = [os.path.join(test_infrared_dir, f) for f in test_filenames]
    test_visible_files = [os.path.join(test_visible_dir, f) for f in test_filenames]

    def process_images(filenames_infrared, filenames_visible, labels):
        infrared_images = []
        visible_images = []
        label_one_hots = []

        for infrared_file, visible_file, label in zip(filenames_infrared, filenames_visible, labels):
            infrared_image = load_image_ir(infrared_file)
            visible_image = load_image(visible_file)
            label_one_hot = tf.one_hot(label, num_classes)

            infrared_images.append(infrared_image.numpy())  # 转为 numpy 数组
            visible_images.append(visible_image.numpy())
            label_one_hots.append(label_one_hot.numpy())

        return np.array(infrared_images), np.array(visible_images), np.array(label_one_hots)

    x_train_infrared, x_train_visible, y_train = process_images(train_infrared_files, train_visible_files, train_labels)
    x_test_infrared, x_test_visible, y_test = process_images(test_infrared_files, test_visible_files, test_labels)

    def shuffle_data(x_infrared, x_visible, y):
        indices = np.arange(x_infrared.shape[0])
        np.random.shuffle(indices)
        return x_infrared[indices], x_visible[indices], y[indices]

    x_train_infrared, x_train_visible, y_train = shuffle_data(x_train_infrared, x_train_visible, y_train)
    x_test_infrared, x_test_visible, y_test = shuffle_data(x_test_infrared, x_test_visible, y_test)

    return (x_train_infrared, x_train_visible, y_train), (x_test_infrared, x_test_visible, y_test)


if tf.config.list_physical_devices('GPU'):
    print("GPU is available")
else:
    print("GPU is NOT available")

physical_devices = tf.config.experimental.list_physical_devices('GPU')
tf.config.experimental.set_memory_growth(device=physical_devices[0], enable=True)

train_infrared_dir = 'aug_dataset_224/train/infrared'
train_visible_dir = 'aug_dataset_224/train/visible'
train_labels_file = 'aug_dataset_224/train/labels.csv'
test_infrared_dir = 'aug_dataset_224/test/infrared'
test_visible_dir = 'aug_dataset_224/test/visible'
test_labels_file = 'aug_dataset_224/test/labels.csv'

(x_train_infrared, x_train_visible, y_train), (x_test_infrared, x_test_visible, y_test) = load_data(
    train_infrared_dir, train_visible_dir, train_labels_file,
    test_infrared_dir, test_visible_dir, test_labels_file)

x_train_infrared = x_train_infrared.astype("float32") / 255.0
x_test_infrared = x_test_infrared.astype("float32") / 255.0
x_train_visible = x_train_visible.astype("float32") / 255.0
x_test_visible = x_test_visible.astype("float32") / 255.0

# 构建融合网络
fusion_model = my_model()
fusion_model.summary()

filepath = 'weights_vgg16_vit_cam_2/vais_vgg16-ca-vit-cam_lam1-0.1_lam2-1_d2_gamma1_nu0.5_checkpoint_1'
checkpoint_callback = ModelCheckpoint(
    filepath, monitor='val_accuracy', verbose=1,
    save_best_only=True, save_weights_only=True,
    save_frequency=1)

fusion_model.fit(x=(x_train_infrared, x_train_visible, y_train), y=y_train, batch_size=16, epochs=100, verbose=1,
                 callbacks=[checkpoint_callback], validation_data=((x_test_infrared, x_test_visible, y_test), y_test))
