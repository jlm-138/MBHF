import tensorflow as tf
from tensorflow import keras


def correlation(ir, rgb):
    eps = tf.keras.backend.epsilon()
    ir = tf.transpose(ir, perm=[0, 3, 1, 2])
    rgb = tf.transpose(rgb, perm=[0, 3, 1, 2])
    n, c, h, w = ir.shape
    ir = tf.reshape(ir, [-1, c, h * w])
    rgb = tf.reshape(rgb, [-1, c, h * w])
    ir = ir - tf.reduce_mean(ir, axis=-1, keepdims=True)
    rgb = rgb - tf.reduce_mean(rgb, axis=-1, keepdims=True)
    cc = tf.reduce_sum(ir * rgb, axis=-1) / (
            eps + tf.sqrt(tf.reduce_sum(ir ** 2, axis=-1)) * tf.sqrt(tf.reduce_sum(rgb ** 2, axis=-1)))
    cc = tf.clip_by_value(cc, -1., 1.)
    cc = tf.reduce_mean(cc)
    return cc


def loss_decom(ir_b, rgb_b, ir_d, rgb_d):
    cc_b1 = correlation(ir_b, rgb_b)
    cc_d1 = correlation(ir_d, rgb_d)
    loss_decomposition = cc_d1 ** 2 / (cc_b1 + 0.01)
    return loss_decomposition


class pl_loss(tf.keras.layers.Layer):
    def __init__(self, lam1, lam2):
        super(pl_loss, self).__init__()
        self.lam1 = lam1
        self.lam2 = lam2

    def call(self, inputs):
        y_true, y_weight1, y_weight2, y_weight3, y_weight4, y_pred, \
         ir_b1, rgb_b1, ir_d1, rgb_d1, ir_b2, rgb_b2, ir_d2, rgb_d2 = inputs

        loss_single = tf.multiply(y_true, tf.math.log(tf.clip_by_value(y_pred, 1e-10, 1.0)), name=None)
        loss_single = -tf.reduce_sum(loss_single, axis=-1)
        ce_loss = tf.reduce_mean(loss_single)

        pl_loss1 = tf.reduce_sum(y_true * y_weight1, -1)
        pl_loss1 = tf.reduce_mean(pl_loss1)

        pl_loss2 = tf.reduce_sum(y_true * y_weight2, -1)
        pl_loss2 = tf.reduce_mean(pl_loss2)

        pl_loss3 = tf.reduce_sum(y_true * y_weight3, -1)
        pl_loss3 = tf.reduce_mean(pl_loss3)

        pl_loss4 = tf.reduce_sum(y_true * y_weight4, -1)
        pl_loss4 = tf.reduce_mean(pl_loss4)

        loss_decomposition1 = loss_decom(ir_b1, rgb_b1, ir_d1, rgb_d1)
        loss_decomposition2 = loss_decom(ir_b2, rgb_b2, ir_d2, rgb_d2)

        total_loss = ce_loss + self.lam1 * pl_loss1 + self.lam1 * pl_loss2 + self.lam1 * pl_loss3 + \
            self.lam1 * pl_loss4 + self.lam2 * loss_decomposition1 + self.lam2 * loss_decomposition2

        # metric
        acc = keras.metrics.categorical_accuracy(y_true, y_pred)
        self.add_loss(total_loss, inputs=True)
        self.add_metric(acc, name="accuracy")
        return total_loss
