import tensorflow as tf


class Distance(tf.keras.layers.Layer):
    def __init__(self, units, input_dim):  # units: number of prototypes, input_dim: dimension of inputs
        super(Distance, self).__init__()
        self.w = self.add_weight(
            name='Prototypes',
            shape=(units, input_dim),
            initializer='random_normal',
            trainable=True
        )

        self.units = units
        self.input_dim = input_dim

    def call(self, inputs):
        for i in range(self.units):
            if i == 0:
                un_mass_i = tf.subtract(self.w[i, :], inputs, name=None)
                un_mass_i = tf.square(un_mass_i, name=None)
                un_mass_i = tf.reduce_sum(un_mass_i, -1, keepdims=True)
                # un_mass_i = tf.sqrt(un_mass_i, name=None)
                un_mass = un_mass_i

            if i >= 1:
                un_mass_i = tf.subtract(self.w[i, :], inputs, name=None)
                un_mass_i = tf.square(un_mass_i, name=None)
                un_mass_i = tf.reduce_sum(un_mass_i, -1, keepdims=True)
                # un_mass_i = tf.sqrt(un_mass_i, name=None)
                un_mass = tf.concat([un_mass, un_mass_i], -1)

        return un_mass  # (None,units)


class DS1_activate(tf.keras.layers.Layer):
    def __init__(self):
        super(DS1_activate, self).__init__()

    def call(self, inputs):
        si = tf.negative(inputs, name=None)
        si = tf.exp(si, name=None)
        return si


class DS2_mass(tf.keras.layers.Layer):
    def __init__(self):
        super(DS2_mass, self).__init__()

    def call(self, inputs):
        mass_omega0 = tf.subtract(1., inputs, name=None)
        mass_omega0 = tf.reduce_prod(mass_omega0, -1, keepdims=True)
        mass = tf.concat([mass_omega0, inputs], -1)
        return mass


class DS2_mass_omega(tf.keras.layers.Layer):
    def __init__(self):
        super(DS2_mass_omega, self).__init__()

    def call(self, inputs):
        inputs_new = tf.expand_dims(inputs, -1)
        mass_omega = tf.subtract(1., inputs_new, name=None)
        mass_with_omega = tf.concat([inputs_new, mass_omega], -1)
        return mass_with_omega


class DS3_Dempster_mass(tf.keras.layers.Layer):
    def __init__(self, num_class):
        super(DS3_Dempster_mass, self).__init__()
        self.num_class = num_class

    def call(self, inputs):
        m1 = tf.expand_dims(inputs[:, 0, 0], -1)
        omega1 = tf.expand_dims(inputs[:, 0, -1], -1)

        for i in range(self.num_class):
            if i == 0:
                m2 = tf.expand_dims(inputs[:, 1, 0], -1)
                omega2 = tf.expand_dims(inputs[:, 1, -1], -1)
                combine1 = tf.multiply(m1, omega2, name=None)
                combine2 = tf.multiply(m2, omega1, name=None)
                combine3 = tf.multiply(omega1, omega2, name=None)
                combine = tf.concat([combine1, combine2], -1)
                combine = tf.concat([combine, combine3], -1)
                combine = tf.divide(combine, tf.reduce_sum(combine, axis=-1, keepdims=True), name=None)   # 归一化
                m1 = combine[:, 0:2]
                omega1 = tf.expand_dims(combine[:, -1], -1)

            if i >= 1:
                m2 = tf.expand_dims(inputs[:, (i+1), 0], -1)
                omega2 = tf.expand_dims(inputs[:, (i+1), -1], -1)
                omega_2 = tf.tile(omega2, [1, (i+1)])
                combine1 = tf.multiply(m1, omega_2, name=None)
                combine2 = tf.multiply(m2, omega1, name=None)
                combine3 = tf.multiply(omega1, omega2, name=None)
                combine = tf.concat([combine1, combine2], -1)
                combine = tf.concat([combine, combine3], -1)
                combine = tf.divide(combine, tf.reduce_sum(combine, axis=-1, keepdims=True), name=None)  # 归一化
                m1 = combine[:, 0:(i+2)]
                omega1 = tf.expand_dims(combine[:, -1], -1)
        return combine


class mass_uncertainty(tf.keras.layers.Layer):
    def __init__(self, num_class):
        super(mass_uncertainty, self).__init__()
        self.num_class = num_class

    def call(self, input):
        m_u = tf.expand_dims(input[:, -1], -1)
        m_single = input[:, 0:-1]
        s_single = -(1. - m_u) * m_single * tf.math.log(m_single + 0.00001) + m_u * (1. - m_single)
        s_u = -m_u * tf.math.log(m_u + 0.00001)
        sum_s_set = tf.cast((tf.math.pow(2, self.num_class+1) - (self.num_class + 3)), tf.float32) * m_u
        sum_s_single = tf.reduce_sum(s_single, axis=-1, keepdims=True)
        uncertainty_m = sum_s_single + sum_s_set + s_u
        return uncertainty_m


class reliability(tf.keras.layers.Layer):
    def __init__(self):
        super(reliability, self).__init__()

    def call(self, inputs):
        u1, u2, u3, u4 = inputs
        u = tf.concat([u1, u2, u3, u4], axis=-1)
        u_sum = tf.reduce_sum(u, axis=-1, keepdims=True)
        rel = tf.subtract(1., tf.divide(u, u_sum))  # (None, 4)
        return rel


class mass_fusion(tf.keras.layers.Layer):
    def __init__(self):
        super(mass_fusion, self).__init__()

    def call(self, input):
        inputs1, inputs2, inputs3, inputs4, input_rel = input  # input_rel:reliability
        inputs1 = tf.expand_dims(inputs1, axis=1)
        inputs2 = tf.expand_dims(inputs2, axis=1)
        inputs3 = tf.expand_dims(inputs3, axis=1)
        inputs4 = tf.expand_dims(inputs4, axis=1)
        inputs = tf.concat([inputs1, inputs2, inputs3, inputs4], axis=1)
        input_rel = tf.expand_dims(input_rel, axis=-1)

        mass_class = inputs[:, :, 0:-1]
        re_mass_class = tf.multiply(input_rel, mass_class, name=None)
        re_mass_u = tf.subtract(1., tf.reduce_sum(re_mass_class, axis=-1, keepdims=True))
        re_inputs = tf.concat([re_mass_class, re_mass_u], axis=-1)

        m1 = re_inputs[:, 0, :]
        omega1 = tf.expand_dims(re_inputs[:, 0, -1], -1)
        for i in range(3):
            m2 = re_inputs[:, (i + 1), :]
            omega2 = tf.expand_dims(re_inputs[:, (i + 1), -1], -1)
            combine1 = tf.multiply(m1, m2, name=None)
            combine2 = tf.multiply(m1, omega2, name=None)
            combine3 = tf.multiply(omega1, m2, name=None)
            combine1_2 = tf.add(combine1, combine2, name=None)
            combine2_3 = tf.add(combine1_2, combine3, name=None)
            combine2_3 = combine2_3 / tf.reduce_sum(combine2_3, axis=-1, keepdims=True)
            m1 = combine2_3
            omega1 = tf.expand_dims(combine2_3[:, -1], -1)
        return m1
