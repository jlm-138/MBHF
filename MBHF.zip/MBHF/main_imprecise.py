"""
两层特征融合；交叉注意力机制;1x1卷积降维
backbone: infrared-vgg16; visible-vgg16; decomp_base-vit; decomp_detail-交叉注意力模块
"""
import tensorflow as tf
import ds_layers
import decision_layer
from keras import layers, models
import os
import pandas as pd
import numpy as np
from keras.layers import Dense, LayerNormalization, Dropout
from scipy.optimize import minimize
import math


class reliability(tf.keras.layers.Layer):
    def __init__(self):
        super(reliability, self).__init__()

    def call(self, inputs):
        u1, u2, u3, u4 = inputs
        u = tf.concat([u1, u2, u3, u4], axis=-1)
        u_sum = tf.reduce_sum(u, axis=-1, keepdims=True)
        rel = tf.subtract(1., tf.divide(u, u_sum))  # (None, 4)
        return rel


class mass_fusion(tf.keras.layers.Layer):
    def __init__(self):
        super(mass_fusion, self).__init__()

    def call(self, input):
        inputs1, inputs2, inputs3, inputs4, input_rel = input  # input_rel:reliability
        inputs1 = tf.expand_dims(inputs1, axis=1)
        inputs2 = tf.expand_dims(inputs2, axis=1)
        inputs3 = tf.expand_dims(inputs3, axis=1)
        inputs4 = tf.expand_dims(inputs4, axis=1)
        inputs = tf.concat([inputs1, inputs2, inputs3, inputs4], axis=1)  # (None, 4, num_class+2)
        input_rel = tf.expand_dims(input_rel, axis=-1)  # (None, 4, 1)

        mass_class = inputs[:, :, 0:-1]
        re_mass_class = tf.multiply(input_rel, mass_class, name=None)
        re_mass_u = tf.subtract(1., tf.reduce_sum(re_mass_class, axis=-1, keepdims=True))
        re_inputs = tf.concat([re_mass_class, re_mass_u], axis=-1)  # (None, 4, num_class+2)

        m1 = re_inputs[:, 0, :]
        omega1 = tf.expand_dims(re_inputs[:, 0, -1], -1)
        for i in range(3):
            m2 = re_inputs[:, (i + 1), :]
            omega2 = tf.expand_dims(re_inputs[:, (i + 1), -1], -1)
            combine1 = tf.multiply(m1, m2, name=None)
            combine2 = tf.multiply(m1, omega2, name=None)
            combine3 = tf.multiply(omega1, m2, name=None)
            combine1_2 = tf.add(combine1, combine2, name=None)
            combine2_3 = tf.add(combine1_2, combine3, name=None)
            combine2_3 = combine2_3 / tf.reduce_sum(combine2_3, axis=-1, keepdims=True)
            m1 = combine2_3
            omega1 = tf.expand_dims(combine2_3[:, -1], -1)
        return m1


class CrossAttention(layers.Layer):
    def __init__(self, num_heads, key_dim):
        super(CrossAttention, self).__init__()
        self.attention = layers.MultiHeadAttention(num_heads=num_heads, key_dim=key_dim)
        self.layer_norm = LayerNormalization(epsilon=1e-6)

    def call(self, query, value):
        # 交叉注意力机制：query来自红外，value来自可见光
        attention_output = self.attention(query, value)
        return self.layer_norm(attention_output + query)  # 残差连接


class ViTBlock(layers.Layer):
    def __init__(self, num_heads, key_dim, ff_dim, rate=0.1):
        super(ViTBlock, self).__init__()
        self.attention = layers.MultiHeadAttention(num_heads=num_heads, key_dim=key_dim)

        self.ffn = models.Sequential([
            layers.Dense(ff_dim, activation='relu'),
            layers.Dense(key_dim * num_heads)
        ])

        self.projection = layers.Dense(key_dim * num_heads)

        self.layernorm1 = layers.LayerNormalization(epsilon=1e-6)
        self.layernorm2 = layers.LayerNormalization(epsilon=1e-6)
        self.dropout1 = layers.Dropout(rate)
        self.dropout2 = layers.Dropout(rate)

    def call(self, inputs):
        attn_output = self.attention(inputs, inputs)
        attn_output = self.dropout1(attn_output)
        out1 = self.layernorm1(inputs + attn_output)

        ffn_output = self.ffn(out1)
        ffn_output = self.dropout2(ffn_output)

        return self.layernorm2(self.projection(out1) + ffn_output)


class ReSoftmaxCrossAttention(layers.Layer):
    def __init__(self, num_heads, key_dim, **kwargs):
        super(ReSoftmaxCrossAttention, self).__init__(**kwargs)
        self.num_heads = num_heads
        self.key_dim = key_dim
        self.query_dense = Dense(key_dim)
        self.key_dense = Dense(key_dim)
        self.value_dense = Dense(key_dim)
        self.output_dense = Dense(key_dim)
        self.layer_norm = LayerNormalization(epsilon=1e-6)

    def call(self, query, value):
        Q = self.query_dense(query)
        K = self.key_dense(value)
        V = self.value_dense(value)

        scores = tf.matmul(Q, K, transpose_b=True)

        weights = tf.nn.softmax(-scores, axis=-1)

        attention_output = tf.matmul(weights, V)
        attention_output = self.output_dense(attention_output)
        return self.layer_norm(attention_output + query)


class ReTransformerEncoderLayer(layers.Layer):
    def __init__(self, num_heads, key_dim, ff_dim, **kwargs):
        super(ReTransformerEncoderLayer, self).__init__(**kwargs)
        self.attention = ReSoftmaxCrossAttention(num_heads=num_heads, key_dim=key_dim)
        self.ffn = tf.keras.Sequential([
            Dense(ff_dim, activation='relu'),
            Dense(key_dim)
        ])
        self.layer_norm1 = LayerNormalization(epsilon=1e-6)
        self.layer_norm2 = LayerNormalization(epsilon=1e-6)
        self.dropout = Dropout(0.1)

    def call(self, query, value):
        attention_output = self.attention(query, value)
        attention_output = self.layer_norm1(attention_output + query)

        ffn_output = self.ffn(attention_output)
        ffn_output = self.layer_norm2(ffn_output + attention_output)

        return self.dropout(ffn_output)


def build_vgg_branch(input_shape):
    base_model = tf.keras.applications.VGG16(include_top=False, weights=None, input_shape=input_shape)
    for layer in base_model.layers:
        layer.trainable = True

    intermediate_layer1 = base_model.get_layer('block2_pool').output
    intermediate_layer3 = base_model.get_layer('block4_pool').output
    final_layer = base_model.output

    model = models.Model(inputs=base_model.input,
                         outputs=[intermediate_layer1, intermediate_layer3, final_layer])
    return model


def my_model():
    input_shape = (224, 224, 3)
    prototypes = 6
    num_class = 6
    num_heads = 2
    key_dim = 64
    ff_dim = 128
    num_heads_cm = 1
    key_dim_cm = 128
    ff_dim_cm = 128

    infrared_model = build_vgg_branch(input_shape)
    visible_model = build_vgg_branch(input_shape)

    infrared_input = infrared_model.input
    visible_input = visible_model.input

    p1_ir, p3_ir, p4_ir = infrared_model(infrared_input)
    p1_rgb, p3_rgb, p4_rgb = visible_model(visible_input)

    feature_ir = tf.keras.layers.Conv2D(128, (1, 1), activation='relu', kernel_initializer='he_normal', padding='same')(p4_ir)
    feature_ir = layers.BatchNormalization()(feature_ir)
    feature_ir = layers.GlobalAveragePooling2D()(feature_ir)
    feature_rgb = tf.keras.layers.Conv2D(128, (1, 1), activation='relu', kernel_initializer='he_normal', padding='same')(p4_rgb)
    feature_rgb = layers.BatchNormalization()(feature_rgb)
    feature_rgb = layers.GlobalAveragePooling2D()(feature_rgb)

    # feature fusion-1
    feature_ir_1 = layers.Conv2D(128, (1, 1), activation='relu', kernel_initializer='he_normal', padding='same')(p1_ir)
    feature_ir_1 = layers.BatchNormalization()(feature_ir_1)
    feature_ir_1 = layers.GlobalAveragePooling2D()(feature_ir_1)
    feature_ir_1 = layers.Reshape((1, 1, -1))(feature_ir_1)

    feature_rgb_1 = layers.Conv2D(128, (1, 1), activation='relu', kernel_initializer='he_normal', padding='same')(p1_rgb)
    feature_rgb_1 = layers.BatchNormalization()(feature_rgb_1)
    feature_rgb_1 = layers.GlobalAveragePooling2D()(feature_rgb_1)
    feature_rgb_1 = layers.Reshape((1, 1, -1))(feature_rgb_1)

    feature_ir_1 = CrossAttention(num_heads=4, key_dim=64)(feature_ir_1, feature_rgb_1)
    feature_rgb_1 = CrossAttention(num_heads=4, key_dim=64)(feature_rgb_1, feature_ir_1)

    vit_base_ir_1 = ViTBlock(num_heads, key_dim, ff_dim)(feature_ir_1)
    final_base_ir_1 = layers.GlobalAveragePooling2D()(vit_base_ir_1)
    vit_base_rgb_1 = ViTBlock(num_heads, key_dim, ff_dim)(feature_rgb_1)
    final_base_rgb_1 = layers.GlobalAveragePooling2D()(vit_base_rgb_1)

    detail_ir_1_feature = ReTransformerEncoderLayer(num_heads_cm, key_dim_cm, ff_dim_cm)(feature_ir_1, feature_rgb_1)
    final_detail_ir_1 = layers.GlobalAveragePooling2D()(detail_ir_1_feature)
    detail_rgb_1_feature = ReTransformerEncoderLayer(num_heads_cm, key_dim_cm, ff_dim_cm)(feature_rgb_1, feature_ir_1)
    final_detail_rgb_1 = layers.GlobalAveragePooling2D()(detail_rgb_1_feature)

    base_1 = layers.add([final_base_ir_1, final_base_rgb_1])
    detail_1 = layers.add([final_detail_ir_1, final_detail_rgb_1])

    fusion_1 = layers.concatenate([base_1, detail_1], axis=-1)
    dense_fusion_1 = layers.Dense(128, activation='relu')(fusion_1)

    # feature fusion-3
    feature_ir_3 = layers.Conv2D(128, (1, 1), activation='relu', kernel_initializer='he_normal', padding='same')(p3_ir)
    feature_ir_3 = layers.BatchNormalization()(feature_ir_3)
    feature_ir_3 = layers.GlobalAveragePooling2D()(feature_ir_3)
    feature_ir_3 = layers.Reshape((1, 1, -1))(feature_ir_3)

    feature_rgb_3 = layers.Conv2D(128, (1, 1), activation='relu', kernel_initializer='he_normal', padding='same')(p3_rgb)
    feature_rgb_3 = layers.BatchNormalization()(feature_rgb_3)
    feature_rgb_3 = layers.GlobalAveragePooling2D()(feature_rgb_3)
    feature_rgb_3 = layers.Reshape((1, 1, -1))(feature_rgb_3)

    feature_ir_3 = CrossAttention(num_heads=4, key_dim=64)(feature_ir_3, feature_rgb_3)
    feature_rgb_3 = CrossAttention(num_heads=4, key_dim=64)(feature_rgb_3, feature_ir_3)

    vit_base_ir_3 = ViTBlock(num_heads, key_dim, ff_dim)(feature_ir_3)
    final_base_ir_3 = layers.GlobalAveragePooling2D()(vit_base_ir_3)
    vit_base_rgb_3 = ViTBlock(num_heads, key_dim, ff_dim)(feature_rgb_3)
    final_base_rgb_3 = layers.GlobalAveragePooling2D()(vit_base_rgb_3)

    detail_ir_3_feature = ReTransformerEncoderLayer(num_heads_cm, key_dim_cm, ff_dim_cm)(feature_ir_3, feature_rgb_3)
    final_detail_ir_3 = layers.GlobalAveragePooling2D()(detail_ir_3_feature)
    detail_rgb_3_feature = ReTransformerEncoderLayer(num_heads_cm, key_dim_cm, ff_dim_cm)(feature_rgb_3, feature_ir_3)
    final_detail_rgb_3 = layers.GlobalAveragePooling2D()(detail_rgb_3_feature)

    base_3 = layers.add([final_base_ir_3, final_base_rgb_3])
    detail_3 = layers.add([final_detail_ir_3, final_detail_rgb_3])

    fusion_3 = layers.concatenate([base_3, detail_3], axis=-1)
    dense_fusion_3 = layers.Dense(128, activation='relu')(fusion_3)

    # evidential classifier-1
    distance_1 = ds_layers.Distance(prototypes, 128)(dense_fusion_1)
    dis_activation_1 = ds_layers.DS1_activate()(distance_1)
    mass_prototypes_1 = ds_layers.DS2_mass()(dis_activation_1)
    mass_with_omega_1 = ds_layers.DS2_mass_omega()(mass_prototypes_1)
    mass_1 = ds_layers.DS3_Dempster_mass(num_class)(mass_with_omega_1)
    uncertainty_m1 = ds_layers.mass_uncertainty(num_class)(mass_1)

    # evidential classifier-3
    distance_3 = ds_layers.Distance(prototypes, 128)(dense_fusion_3)
    dis_activation_3 = ds_layers.DS1_activate()(distance_3)
    mass_prototypes_3 = ds_layers.DS2_mass()(dis_activation_3)
    mass_with_omega_3 = ds_layers.DS2_mass_omega()(mass_prototypes_3)
    mass_3 = ds_layers.DS3_Dempster_mass(num_class)(mass_with_omega_3)
    uncertainty_m3 = ds_layers.mass_uncertainty(num_class)(mass_3)

    # evidential classifier-ir
    distance_ir = ds_layers.Distance(prototypes, 128)(feature_ir)
    dis_activation_ir = ds_layers.DS1_activate()(distance_ir)
    mass_prototypes_ir = ds_layers.DS2_mass()(dis_activation_ir)
    mass_with_omega_ir = ds_layers.DS2_mass_omega()(mass_prototypes_ir)
    mass_ir = ds_layers.DS3_Dempster_mass(num_class)(mass_with_omega_ir)
    uncertainty_ir = ds_layers.mass_uncertainty(num_class)(mass_ir)

    # evidential classifier-rgb
    distance_rgb = ds_layers.Distance(prototypes, 128)(feature_rgb)
    dis_activation_rgb = ds_layers.DS1_activate()(distance_rgb)
    mass_prototypes_rgb = ds_layers.DS2_mass()(dis_activation_rgb)
    mass_with_omega_rgb = ds_layers.DS2_mass_omega()(mass_prototypes_rgb)
    mass_rgb = ds_layers.DS3_Dempster_mass(num_class)(mass_with_omega_rgb)
    uncertainty_rgb = ds_layers.mass_uncertainty(num_class)(mass_rgb)

    rel = reliability()([uncertainty_m1, uncertainty_m3, uncertainty_ir, uncertainty_rgb])

    # decision fusion
    mass = mass_fusion()([mass_1, mass_3, mass_ir, mass_rgb, rel])

    outputs = decision_layer.DM_test(num_class, 64, 0.5)(mass)

    model = tf.keras.Model(inputs=[infrared_input, visible_input], outputs=[outputs])
    model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.001), run_eagerly=True)
    return model


def load_image_ir(image_file):
    image = tf.io.read_file(image_file)
    image = tf.image.decode_image(image, channels=3)
    return image


def load_image(image_file):
    image = tf.io.read_file(image_file)
    image = tf.image.decode_image(image, channels=3)
    return image


def load_data(train_infrared_dir, train_visible_dir, train_labels_file,
              test_infrared_dir, test_visible_dir, test_labels_file, num_classes=6):
    train_labels_df = pd.read_csv(train_labels_file)
    train_filenames = train_labels_df['filename'].values
    train_labels = train_labels_df['label'].values

    test_labels_df = pd.read_csv(test_labels_file)
    test_filenames = test_labels_df['filename'].values
    test_labels = test_labels_df['label'].values

    train_infrared_files = [os.path.join(train_infrared_dir, f) for f in train_filenames]
    train_visible_files = [os.path.join(train_visible_dir, f) for f in train_filenames]

    test_infrared_files = [os.path.join(test_infrared_dir, f) for f in test_filenames]
    test_visible_files = [os.path.join(test_visible_dir, f) for f in test_filenames]

    def process_images(filenames_infrared, filenames_visible, labels):
        infrared_images = []
        visible_images = []
        label_one_hots = []

        for infrared_file, visible_file, label in zip(filenames_infrared, filenames_visible, labels):
            infrared_image = load_image_ir(infrared_file)
            visible_image = load_image(visible_file)
            label_one_hot = tf.one_hot(label, num_classes)

            infrared_images.append(infrared_image.numpy())
            visible_images.append(visible_image.numpy())
            label_one_hots.append(label_one_hot.numpy())

        return np.array(infrared_images), np.array(visible_images), np.array(label_one_hots)

    x_train_infrared, x_train_visible, y_train = process_images(train_infrared_files, train_visible_files, train_labels)
    x_test_infrared, x_test_visible, y_test = process_images(test_infrared_files, test_visible_files, test_labels)

    def shuffle_data(x_infrared, x_visible, y):
        indices = np.arange(x_infrared.shape[0])
        np.random.shuffle(indices)
        return x_infrared[indices], x_visible[indices], y[indices]

    x_train_infrared, x_train_visible, y_train = shuffle_data(x_train_infrared, x_train_visible, y_train)
    x_test_infrared, x_test_visible, y_test = shuffle_data(x_test_infrared, x_test_visible, y_test)

    return (x_train_infrared, x_train_visible, y_train), (x_test_infrared, x_test_visible, y_test)


# aim func: cross entropy
def func(x):
    fun = 0
    for i in range(len(x)):
        fun += x[i] * math.log10(x[i])
    return fun


# constraint 1: the sum of weights is 1
def cons1(x):
    return sum(x)


# constraint 2: define tolerance to imprecision
def cons2(x):
    tol = 0
    for i in range(len(x)):
        tol += (len(x) - (i + 1)) * x[i] / (len(x) - 1)
    return tol


if __name__ == "__main__":
    num_classes = 6

    train_infrared_dir = 'aug_dataset_224/train/infrared'
    train_visible_dir = 'aug_dataset_224/train/visible'
    train_labels_file = 'aug_dataset_224/train/labels.csv'
    test_infrared_dir = 'aug_dataset_224/test/infrared'
    test_visible_dir = 'aug_dataset_224/test/visible'
    test_labels_file = 'aug_dataset_224/test/labels.csv'

    (x_train_infrared, x_train_visible, y_train_label), (x_test_infrared, x_test_visible, y_test_label) = load_data(
        train_infrared_dir, train_visible_dir, train_labels_file,
        test_infrared_dir, test_visible_dir, test_labels_file)

    x_train_infrared = x_train_infrared.astype("float32") / 255.0
    x_test_infrared = x_test_infrared.astype("float32") / 255.0
    x_train_visible = x_train_visible.astype("float32") / 255.0
    x_test_visible = x_test_visible.astype("float32") / 255.0

    y_test = tf.argmax(y_test_label, axis=1)

    # 计算效用矩阵

    # compute the weights g for ordered weighted average aggreagtion
    num_class = 6
    for j in range(2, (num_class+1)):
        num_weights = j
        ini_weights = np.asarray(np.random.rand(num_weights))
        name = 'weight' + str(j)
        locals()['weight'+str(j)] = np.zeros([5, j])

        for i in range(5):
            tol = 0.5 + i * 0.1

            cons = ({'type': 'eq', 'fun': lambda x: cons1(x)-1},
                {'type': 'eq', 'fun': lambda x: cons2(x)-tol},
                {'type': 'ineq', 'fun': lambda x: x-0.00000001}
                )

            res = minimize(func, ini_weights, method='SLSQP', options={'disp': True}, constraints=cons)
            locals()['weight'+str(j)][i] = res.x
            # print(res.x)

    # function for power set
    def PowerSetsBinary(items):
        # generate all combination of N items
        N = len(items)
        # enumerate the 2**N possible combinations
        set_all = []
        for i in range(2**N):
            combo = []
            for j in range(N):
                if(i >> j) % 2 == 1:
                    combo.append(items[j])
            set_all.append(combo)
        return set_all


    class_set = list(range(num_class))
    act_set = PowerSetsBinary(class_set)
    act_set_all = sorted(act_set)
    act_set.remove(act_set[0])
    act_set = sorted(act_set)
    # print(act_set_all)
    print(len(act_set_all))
    # print(act_set)
    print(len(act_set))


    def average_utility(utility_matrix, inputs, labels):
        utility = 0
        for i in range(len(inputs)):
            x = inputs[i]
            y = labels[i]
            utility += utility_matrix[x, y + 1]
        average_utility = utility / len(inputs)
        return average_utility

    number_act_set = len(act_set_all)


    print('\nv=0\n')
    for tol in range(4):
        utility_matrix = np.zeros([len(act_set), len(class_set)])
        tol_i = tol + 1
        # tol_i = 0 with tol=0.5, tol_i = 1 / tol=0.6, tol_i = 2 / tol=0.7, tol_i = 3 / tol=0.8, tol_i = 4 / tol=0.9
        for i in range(len(act_set)):
            intersec = class_set and act_set[i]
            if len(intersec) == 1:
                utility_matrix[i, intersec] = 1
            else:
                for j in range(len(intersec)):
                    utility_matrix[i, intersec[j]] = locals()['weight' + str(len(intersec))][tol_i, 0]
        h = np.zeros([len(act_set), 1])
        utility_matrix = np.hstack((h, utility_matrix))
        v = np.zeros([1, len(class_set) + 1])
        # v[0, 0] = 0
        utility_matrix = np.vstack((v, utility_matrix))
        # print(utility_matrix)

        model_e_imprecise0 = my_model()
        model_e_imprecise0.layers[-1].set_weights(tf.reshape(utility_matrix, [1, 64, 7]))

        model_e_imprecise0.load_weights('weights_aug_vgg16_vit_cam_2/aug-vais_vgg16-ca-vit-cam_lam1-0.1_lam2-0.1_d2_gamma1_nu0.5_checkpoint_5').expect_partial()

        results = tf.argmax(model_e_imprecise0.predict([x_test_infrared, x_test_visible]), -1)
        imprecise_results = []
        for i in range(len(results)):
            act_local = results[i]
            set_valued_results = act_set_all[act_local]
            imprecise_results.append(set_valued_results)
        # print("\nimprecise_results:\n", imprecise_results)

        average_utility_imprecision = average_utility(utility_matrix, results, y_test)
        print("average_utility:", average_utility_imprecision)

        number = 0
        for i in range(len(imprecise_results)):
            number = number + len(imprecise_results[i])
        average_c = tf.divide(number, len(imprecise_results), name=None)
        print('average_cardinality: ', average_c)
